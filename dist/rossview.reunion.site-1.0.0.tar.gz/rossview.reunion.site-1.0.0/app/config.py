SECRET_KEY = 'super secret squirrel'
MAILGUN_ENDPOINT = ''
MAILGUN_API_KEY = ''
EMAIL_FROM = 'rossviewapp@elcreativegroup.com'
EMAIL_TO = ['n.e.lorenson@gmail.com']
EMAIL_SUBJECT = 'TEST MAIL'
